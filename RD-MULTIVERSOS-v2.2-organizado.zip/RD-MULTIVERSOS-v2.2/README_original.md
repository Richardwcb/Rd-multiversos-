# RD Multiversos v2 — pacote inicial

Este pacote prepara a estrutura do site e do painel. **Não está conectado ao Supabase nem a pagamentos** até você configurar os serviços e executar os passos abaixo.

## Arquitetura
- Site e painel estáticos no Netlify.
- Supabase Auth para login administrativo.
- Supabase Postgres para clientes, serviços e pedidos.
- RLS no banco restringe os dados a administradores.
- Pagamentos reais ficam desativados até a integração segura do provedor.

## Configuração
1. Crie um projeto em https://supabase.com/.
2. Execute `supabase/schema.sql` no SQL Editor do Supabase.
3. Em Authentication > Users, crie o usuário administrador com e-mail seu e senha forte.
4. Copie o UUID do usuário e execute no SQL Editor:
   `insert into public.admin_users (user_id) values ('COLE-O-UUID-AQUI');`
5. Copie `config.example.js` para `config.js` e preencha URL do projeto e chave publicável (ou `anon` legada).
6. Nunca use a chave `service_role`/secret no navegador ou no repositório.
7. Envie os arquivos para o Netlify e abra `/admin.html`.
8. Teste com um usuário que não esteja em `admin_users`: ele não deve conseguir acessar dados.

## Pagamentos
A tabela `payments` é apenas uma estrutura futura. Ela não cobra nem confirma pagamentos.
Para ativar, implemente uma função de servidor que cria a cobrança usando credenciais guardadas como secrets, calcula o valor a partir do pedido no banco e valida webhooks oficiais do provedor. Use primeiro o ambiente de testes. Nunca trate uma página de retorno como prova de pagamento e nunca armazene cartão/CVV.

## Antes de lançar
- Revise preços e textos.
- Adicione política de privacidade e processo para solicitações LGPD.
- Ative MFA no login administrativo, se disponível.
- Teste RLS e acesso negado.
