create extension if not exists pgcrypto;

create table if not exists public.admin_users (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

create or replace function public.is_rd_admin()
returns boolean language sql stable security definer set search_path = public
as $$ select exists (select 1 from public.admin_users a where a.user_id = auth.uid()); $$;
revoke all on function public.is_rd_admin() from public;
grant execute on function public.is_rd_admin() to authenticated;

create table if not exists public.clients (
  id uuid primary key default gen_random_uuid(),
  name text not null check (char_length(name) between 1 and 120),
  email text, whatsapp text, notes text,
  created_at timestamptz not null default now()
);
create table if not exists public.services (
  id uuid primary key default gen_random_uuid(),
  name text not null check (char_length(name) between 1 and 120),
  description text not null default '',
  base_price numeric(10,2) not null default 0 check (base_price >= 0),
  active boolean not null default true,
  created_at timestamptz not null default now()
);
create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  client_id uuid not null references public.clients(id) on delete restrict,
  service_id uuid references public.services(id) on delete set null,
  title text not null check (char_length(title) between 1 and 180),
  details text not null default '',
  agreed_amount numeric(10,2) not null check (agreed_amount >= 0),
  status text not null default 'novo' check (status in
    ('novo','em_orcamento','aguardando_pagamento','pago','em_andamento','concluido','cancelado')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table if not exists public.payments (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete restrict,
  provider text not null,
  external_payment_id text,
  amount numeric(10,2) not null check (amount >= 0),
  currency text not null default 'BRL' check (currency = 'BRL'),
  status text not null default 'pending' check (status in
    ('pending','approved','rejected','cancelled','refunded')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(provider, external_payment_id)
);

revoke all privileges on table
  public.admin_users,
  public.clients,
  public.services,
  public.orders,
  public.payments
from public, anon, authenticated;

alter table public.admin_users enable row level security;
alter table public.clients enable row level security;
alter table public.services enable row level security;
alter table public.orders enable row level security;
alter table public.payments enable row level security;

drop policy if exists "admin reads own membership" on public.admin_users;
create policy "admin reads own membership" on public.admin_users
for select to authenticated using (user_id = auth.uid());

drop policy if exists "rd admin manages clients" on public.clients;
create policy "rd admin manages clients" on public.clients
for all to authenticated using (public.is_rd_admin()) with check (public.is_rd_admin());
drop policy if exists "rd admin manages services" on public.services;
create policy "rd admin manages services" on public.services
for all to authenticated using (public.is_rd_admin()) with check (public.is_rd_admin());
drop policy if exists "rd admin manages orders" on public.orders;
create policy "rd admin manages orders" on public.orders
for all to authenticated using (public.is_rd_admin()) with check (public.is_rd_admin());
drop policy if exists "rd admin reads payments" on public.payments;
create policy "rd admin reads payments" on public.payments
for select to authenticated using (public.is_rd_admin());

grant select, insert, update, delete on public.clients to authenticated;
grant select, insert, update, delete on public.services to authenticated;
grant select, insert, update, delete on public.orders to authenticated;
grant select on public.payments to authenticated;
revoke insert, update, delete on public.payments from anon, authenticated;

-- Seeds: insere cada serviço padrão apenas se ainda não existir um com o mesmo nome.
-- Se já houver serviços personalizados com esses nomes, eles não serão sobrescritos.
insert into public.services (name, description, base_price)
select seed.name, seed.description, seed.base_price
from (values
  ('Criação de sites','Site institucional ou página comercial; orçamento conforme escopo.',350::numeric),
  ('Design gráfico','Peças digitais; preço conforme complexidade.',35::numeric),
  ('Edição de imagens','Tratamento e edição de imagens.',20::numeric),
  ('Edição de vídeos','Edição de vídeos sob consulta.',60::numeric),
  ('Automação digital','Fluxos digitais; orçamento após análise.',250::numeric)
) as seed(name, description, base_price)
where not exists (
  select 1 from public.services existing where existing.name = seed.name
);

grant select on public.admin_users to authenticated;
