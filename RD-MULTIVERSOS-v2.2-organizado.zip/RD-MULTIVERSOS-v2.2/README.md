# RD Multiversos v2.2 — pacote organizado

Este pacote reúne os arquivos recebidos e inclui pequenas correções de segurança/robustez. Não contém credenciais reais e não foi conectado ao seu projeto Supabase/Netlify.

## Estrutura
- `index.html`: página pública.
- `admin.html`, `admin.js`: painel administrativo.
- `config.example.js`: modelo de configuração; copie para `config.js` e preencha localmente.
- `supabase/schema.sql`: versão preparada para uso, com inserção dos serviços padrão sem duplicá-los em execuções repetidas.
- `supabase/schema_original.sql`: cópia do SQL recebido, sem alterações.
- `README_original.md`: documentação original recebida.
- `netlify/functions/`, `assets/`, `pages/`, `supabase/migrations/` e `supabase/policies/`: pastas reservadas para expansão futura.

## Configuração
1. No Supabase, revise `supabase/schema.sql` antes de executar no SQL Editor. `CREATE TABLE IF NOT EXISTS` não atualiza automaticamente uma tabela existente com estrutura diferente. Faça backup antes de aplicar mudanças em um banco que já tenha dados.
2. Crie o usuário administrador em Supabase Authentication.
3. Insira o UUID desse usuário em `public.admin_users`, por exemplo: `insert into public.admin_users (user_id) values ('UUID-DO-USUARIO');`
4. Copie `config.example.js` para `config.js` e informe `SUPABASE_URL` e `SUPABASE_PUBLISHABLE_KEY`. Não publique `config.js` com nada além de URL e chave publicável.
5. Publique os arquivos no Netlify e teste `/admin.html`.
6. Teste com um usuário autenticado que não esteja em `admin_users`; ele não deve conseguir ler ou alterar dados administrativos.

## Notas de revisão
- O painel usa Supabase Auth e consulta `admin_users` para validar a autorização. A segurança real depende também das políticas RLS do banco.
- `payments` permanece somente leitura para `authenticated`; o pacote não processa pagamentos nem confirma cobranças.
- A inserção dos serviços padrão agora verifica se já existe um serviço com o mesmo nome, reduzindo duplicações em execuções repetidas.
- O painel mostra uma mensagem clara se tentarem entrar antes de configurar `config.js`.
- Antes de lançamento, revise política de privacidade/LGPD, MFA, preços, textos e os testes de RLS.

## Segredos
Nunca inclua no navegador ou no repositório a chave `service_role`/secret, senhas, tokens privados ou credenciais de pagamento.
