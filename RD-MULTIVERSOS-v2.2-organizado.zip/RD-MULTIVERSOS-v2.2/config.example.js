// Copie para config.js e preencha. Só valores públicos aqui.
// NUNCA coloque service_role/secret key ou credenciais de pagamento.
window.RD_CONFIG = {
  SUPABASE_URL: "https://SEU-PROJETO.supabase.co",
  SUPABASE_PUBLISHABLE_KEY: "SUA_CHAVE_PUBLICAVEL"
};
