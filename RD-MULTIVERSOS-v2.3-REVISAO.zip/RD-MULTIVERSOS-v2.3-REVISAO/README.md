# RD Multiversos v2.3 — versão visual para revisão

Esta é uma atualização visual do RD Multiversos v2.2, preparada para revisão antes de qualquer publicação. O site público recebeu identidade futurista (preto, azul, ciano e roxo), apresentação reorganizada e melhor adaptação a telas móveis. A página administrativa recebeu uma atualização visual sem alterar a lógica JavaScript.

**Nenhuma alteração foi feita no projeto publicado do Netlify. Nenhum SQL foi executado no Supabase.**

## Estrutura
- `index.html`: página pública.
- `admin.html`, `admin.js`: painel administrativo.
- `config.example.js`: modelo de configuração; copie para `config.js` e preencha localmente.
- `supabase/schema.sql`: versão preparada para uso, com inserção dos serviços padrão sem duplicá-los em execuções repetidas.
- `supabase/schema_original.sql`: cópia do SQL recebido, sem alterações.
- `README_original.md`: documentação original recebida.
- `netlify/functions/`, `assets/`, `pages/`, `supabase/migrations/` e `supabase/policies/`: pastas reservadas para expansão futura.

## Configuração
1. No Supabase, revise `supabase/schema.sql` antes de executar no SQL Editor. `CREATE TABLE IF NOT EXISTS` não atualiza automaticamente uma tabela existente com estrutura diferente. Faça backup antes de aplicar mudanças em um banco que já tenha dados.
2. Crie o usuário administrador em Supabase Authentication.
3. Insira o UUID desse usuário em `public.admin_users`, por exemplo: `insert into public.admin_users (user_id) values ('UUID-DO-USUARIO');`
4. Copie `config.example.js` para `config.js` e informe `SUPABASE_URL` e `SUPABASE_PUBLISHABLE_KEY`. Não publique `config.js` com nada além de URL e chave publicável.
5. Publique os arquivos no Netlify e teste `/admin.html`.
6. Teste com um usuário autenticado que não esteja em `admin_users`; ele não deve conseguir ler ou alterar dados administrativos.

## Notas de revisão
- O painel usa Supabase Auth e consulta `admin_users` para validar a autorização. A segurança real depende também das políticas RLS do banco.
- `payments` permanece somente leitura para `authenticated`; o pacote não processa pagamentos nem confirma cobranças.
- A inserção dos serviços padrão agora verifica se já existe um serviço com o mesmo nome, reduzindo duplicações em execuções repetidas.
- O painel mostra uma mensagem clara se tentarem entrar antes de configurar `config.js`.
- Antes de lançamento, revise política de privacidade/LGPD, MFA, preços, textos e os testes de RLS.

## Segredos
Nunca inclua no navegador ou no repositório a chave `service_role`/secret, senhas, tokens privados ou credenciais de pagamento.


## Alterações desta versão
- Página inicial redesenhada com visual futurista responsivo.
- Serviços e valores mantidos conforme solicitado: criação de sites (R$ 350), design gráfico (R$ 35), edição de imagens (R$ 20), edição de vídeos (R$ 60) e automação digital (R$ 250).
- Textos deixam claro que os preços são valores iniciais de referência e precisam ser confirmados no orçamento.
- Chamadas de orçamento por WhatsApp mantidas com o número que já estava no pacote original: +55 11 92480-4584. Confirme se esse é o contato comercial correto antes de publicar.
- Não foi inventado portfólio ou depoimento de clientes.
- A página administrativa recebeu apenas melhorias visuais; a integração com Supabase ainda depende de configuração e testes.

## Antes de publicar
1. Confirmar o número comercial do WhatsApp.
2. Conferir os valores e o que cada preço inclui (unidade, pacote, quantidade de revisões e limites de escopo).
3. Configurar `config.js` somente com a URL do projeto e a chave publicável do Supabase.
4. Revisar o SQL e as políticas RLS; não executar este pacote sem backup e revisão do banco atual.
5. Testar o login administrativo e as permissões com contas autorizadas e não autorizadas.
6. Publicar primeiro como deploy de prévia, sem substituir a versão principal até a aprovação.
